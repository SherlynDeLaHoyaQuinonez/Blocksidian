Dependency installation:

npm install || npm i

--------------------------------------
React use the port localhost:3000

In the project directory, you can run:

npm run start
